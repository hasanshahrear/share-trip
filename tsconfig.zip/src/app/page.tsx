import { FlightDetails } from "@/features";

export default function Home() {
  return (
    <FlightDetails />
  );
}
