import { Header, Sidebar } from "@/features";
import type { Metadata } from "next";
import { Inter } from "next/font/google";
import "./globals.css";

const inter = Inter({ subsets: ["latin"] });

export const metadata: Metadata = {
  title: "ShareTrip",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body className={`${inter.className} bg-[#EBF0F5]`}>
        <Header />
        <div className="w-[1112px] mx-auto flex gap-6">
          <Sidebar />
          {children}
        </div>
        </body>
    </html>
  );
}
