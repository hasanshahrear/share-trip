export function Sidebar(){
    return (
        <div className="bg-white min-w-[248px]  rounded-lg h-screen"></div>
    )
}