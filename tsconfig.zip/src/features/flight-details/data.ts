
export const breadCrumbData = [
    "Home",
    "Booking History",
    "Flight",
    "STFL17121182045413",
]