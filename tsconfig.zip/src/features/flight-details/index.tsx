export { FlightDetails } from "./flight-details.component";
