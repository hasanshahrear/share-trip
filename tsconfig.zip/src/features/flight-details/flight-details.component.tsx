import { Breadcrumb } from "../ui/breadcrumb/breadcrumb.component";
import { breadCrumbData } from "./data";

export function FlightDetails(){
    return (
        <div className="w-full">
            <div>
                <Breadcrumb breadCrumb={breadCrumbData} />
            </div>
           <div className="bg-white rounded-lg">
            test
           </div>
        </div>
    )
}